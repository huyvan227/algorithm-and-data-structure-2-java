public class Prim{
	public Prim(){

	}
	public void PrimSearch(Graph g){
		Edge T[] = new Edge[g.getSize()-1];
		int sizeT = 0;
		int matrix[][] = g.getMatrix();
		Boolean check[] = new Boolean[g.getSize()];
		for (int i = 0;i<g.getSize();i++){
			check[i] = false;
		}
		while(sizeT<g.getSize()-1){
			for (int i = 0;i<g.getSize();i++){
				if(!check[i]){
					check[i] = true;
					Edge min = new Edge(0,0,0);
					int minValue = Integer.MAX_VALUE;
					for(int j = 0;j<g.getSize();j++){
						if(matrix[i][j]!=0 && !check[j]&&matrix[i][j]<minValue){
							minValue = matrix[i][j];
							min.setSource(i);
							min.setDest(j);
							min.setValue(matrix[i][j]);
						}
					}
					try{
						T[sizeT] = new Edge(0,0,0);
						T[sizeT] = min;
						sizeT++;

					}catch(Exception e){};
				}
			}
		int sum = 0;
		for (int i = 0;i<T.length;i++){
			T[i].print();
			sum += T[i].getValue();
		}
		System.out.println("Minimum Value: "+ sum);
	
		}
	}
}
	