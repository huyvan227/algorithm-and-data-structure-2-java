
public class Demo {
	public static void main(String[] args) {
		Graph graph = new Graph("io.txt");
		System.out.println(graph.getSize());
		int[][] a = graph.getMatrix();
		for(int i = 0; i<graph.getSize(); i++) {
			for(int j = 0; j<graph.getSize(); j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		Prim Testprim = new Prim();
		Testprim.PrimSearch(graph);
		
	}
}
